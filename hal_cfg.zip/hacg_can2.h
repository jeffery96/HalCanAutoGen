/********************************************************************************
 * Copyright 2023 Wisdom (Fujian) Motor Co.,Ltd.
 * All Rights Reserved.
 * Dept.:Software Department.
 * FILE: hacg_can2.h
 * Description: This file is automatic generate by HalCanAutoGen.
 * History:
 * 2023-03-19 LinXiaobin
********************************************************************************/

#include "build_control.h"

#ifndef __HACG_CAN2__
#define __HACG_CAN2__

extern void Can2Msg_Pack_0x18f10527(void);
extern void Can2Msg_Unpack_0xcf603a1(void);

#endif /*End of __HACG_CAN2__*/
/*-------------------------------------EOF--------------------------------------*/

